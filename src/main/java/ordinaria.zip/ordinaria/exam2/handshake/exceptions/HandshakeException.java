package ordinaria.exam2.handshake.exceptions;

public class HandshakeException extends Exception {
    public HandshakeException(String message) {
        super(message);
    }
}
