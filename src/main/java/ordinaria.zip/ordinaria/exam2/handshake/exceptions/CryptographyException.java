package ordinaria.exam2.handshake.exceptions;

public class CryptographyException extends Exception {
    public CryptographyException(String message) {
        super(message);
    }
}
