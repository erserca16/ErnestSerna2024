package exam2.server;

import ud4.examples.Config;

import javax.net.ssl.SSLServerSocketFactory;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.List;

public class MessagingServer extends Thread {
    ServerSocket server;
    List<MessagingServerHandler> clients;
    boolean running;

    public MessagingServer() throws IOException {
        // TODO: Crea un SocketServer mitjançant JSSE
        /*
            keytool -genkey -keyalg RSA \
            -alias chat-server \
            -keystore files/ud4/chat/chat-server.jks \
            -storepass 123456 -keysize 2048 \
            -dname "CN=ChatSercer, OU=PSP-DAM2S, O=CIPFP Mislata, L=Mislata, ST=València, C=ES"
         */
        Properties config = Config.getConfig("application.properties");
        int port = Integer.parseInt(config.getProperty("exam2.port"));
        System.out.println("Creant el Socket servidor en el port: " + port);

        String keyStorePath = config.getProperty("exam2.keystore.path");
        String keyStorePassword = config.getProperty("exam2.keystore.passwd");

        System.setProperty("javax.net.ssl.keyStore", keyStorePath);
        System.setProperty("javax.net.ssl.keyStorePassword", keyStorePassword);

        SSLServerSocketFactory sslserversocketfactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
        server = sslserversocketfactory.createServerSocket(port);
        clients = new ArrayList<>();
        running = true;
    }

    public void close(){
        running = false;
        this.interrupt();
    }

    public synchronized void removeClient(MessagingServerHandler hc){
        clients.remove(hc);
    }

    /**
     * Retorna el client amb el alies especificat o null si no existeix
     * @param alias Alias de la persona a la que li envies el missatge
     * @return Retorna el client amb el alies especificat o null si no existeix
     */
    public MessagingServerHandler getClientByAlias(String alias){
        return clients.stream().filter(c -> c.getAlias().equals(alias)).findAny().orElse(null);
    }
    /**
     * Retorna els alies dels clients connectats separats per comes
     * @return Alies dels clients connectats separats per comes
     */
    public String connectedClients(){
        return clients.stream().map(MessagingServerHandler::getAlias).collect(Collectors.joining(","));
    }


    @Override
    public void run() {
        while (running){
            try {
                Socket client = server.accept();
                MessagingServerHandler messagingServerHandler = new MessagingServerHandler(client, this);
                clients.add(messagingServerHandler);
                messagingServerHandler.start();
                System.out.println("Nova connexió acceptada.");
            } catch (IOException e) {
                System.err.println("Error while accepting new connection");
                System.err.println(e.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);
            MessagingServer server = new MessagingServer();
            server.start();

            scanner.nextLine();

            server.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
