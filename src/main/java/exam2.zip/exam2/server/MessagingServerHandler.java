package exam2.server;

import exam2.models.Request;
import exam2.models.RequestType;

import java.io.*;
import java.net.Socket;

public class MessagingServerHandler extends Thread {
    private final MessagingServer server;
    private final Socket client;
    //private final ObjectInputStream objIn;
    //private final ObjectOutputStream objOut;
    private final PrintWriter out;
    private final BufferedReader in;

    // TODO: ObjectStream related object

    private String alias;

    public MessagingServerHandler(Socket client, MessagingServer server) throws IOException {
        this.server = server;
        this.client = client;
        this.in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        this.out = new PrintWriter(client.getOutputStream(), true);
        //objIn = new ObjectInputStream(client.getInputStream());
       // objOut = new ObjectOutputStream(client.getOutputStream());
        alias = "";
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    /**
     * TODO: Envia una petició
     * @param request Petició a enviar
     * @throws IOException
     */
    public void sendRequest(Request request) throws IOException {
        out.println();
    }

    /**
     * TODO: Llegeix una petició
     * @return Petició llegida
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public Request readRequest() throws IOException, ClassNotFoundException {
        // TODO
        return null;
    }

    /**
     * TODO: Acció del servidor a les respostes del tipus SEND
     * @param request Petició a processar
     */
    private void processSend(Request request) throws IOException {
    }

    /**
     * TODO: Acció del servidor a les respostes del tipus CHANGE_NAME
     * @param request Petició a processar
     */
    private void processChangeName(Request request) throws IOException {
    }

    /**
     * TODO: Acció del servidor a les respostes del tipus LIST
     * @param request Petició a processar
     */
    private void processList(Request request) throws IOException {
    }

    @Override
    public void run() {
        try {
            Request request;
            while((request = readRequest()) != null){
                System.out.println(request);
                if (request.getType() == RequestType.SEND){
                    processSend(request);
                } else if (request.getType() == RequestType.CHANGE_NAME){
                    processChangeName(request);
                } else if (request.getType() == RequestType.LIST){
                    processList(request);
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            System.err.println(e.getMessage());
        }
        server.removeClient(this);
    }
}
